from django.db import models
from academic_affairs.models.Semester import Semester
from django.db.models import Q

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _


class Period4Exam(SoftDeleteModel):
     fk_semester = models.ForeignKey(Semester, related_name='period_4_exam_set', on_delete=models.CASCADE)
     time_from = models.TimeField(verbose_name=_("Time From"))
     time_to = models.TimeField(verbose_name=_("Time To"))
     order_no = models.PositiveSmallIntegerField(verbose_name=_("Order No"))

     class Meta:
          verbose_name =_("Period 4Exam")
          verbose_name_plural =_("Period 4 Exams")
          constraints = [
                    models.UniqueConstraint(
                         fields=['fk_semester','order_no'],
                         name='unique_fk_semester_4b_order_no_no_deleted',
                         condition=Q(is_deleted=False),
                    )
               ]