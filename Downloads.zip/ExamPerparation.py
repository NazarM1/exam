from django.db import models
from .ExamSchedule import ExamSchedule
from student_affairs.models.StudentCourse import StudentSemester


from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel, models
from django.utils.translation  import gettext_lazy as _

class ExamPerparation(SoftDeleteModel):
     fk_student_semester         = models.ForeignKey(StudentSemester,related_name='ep_student',on_delete =models.CASCADE,verbose_name=_("Studen"))
     fk_exam_schedule   = models.ForeignKey(ExamSchedule,related_name='ep_exam_schedule',on_delete =models.CASCADE,verbose_name=_("Exam Schedule"))
     date               = models.DateTimeField(verbose_name=_("Date"))
     is_present         = models.BooleanField(default=False,verbose_name=_("Is Present"))
     note               = models.CharField( max_length=250, blank=True, null=True,verbose_name=_("Note"))

     class Meta:
          verbose_name=_("Exam Perparation")
          verbose_name_plural=_("Exam Perparations")