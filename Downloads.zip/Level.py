
from django.db import models
from .Batch import Batch
from DRFBaselCoreU.common.models.Branch import Organization
from django.db.models import Q

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _
from system_management.choices.choices import LevelChoice
from system_management.models.AcademicYear import AcademicYear

class Level(SoftDeleteModel):
    fk_batch = models.ForeignKey(Batch,verbose_name = _("Batch"), on_delete=models.PROTECT,related_name='level_set')
    fk_academic_year = models.ForeignKey(AcademicYear,verbose_name=_("Academic Year"), related_name='level_set', on_delete=models.PROTECT)
    level = models.PositiveSmallIntegerField(choices=LevelChoice.choices,verbose_name=_("Level"))
    is_current = models.BooleanField(default=False,verbose_name=_("Is Current"))
    allowed_failure_subjects = models.PositiveSmallIntegerField(verbose_name=_("Allowed Failure Subjects"))

    def __str__(self):
        return f'{self.level} - {self.fk_batch.batch_no}'

    class Meta:
        verbose_name =_("المستوى")
        verbose_name_plural=_("المتسويات")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_batch','fk_academic_year'],
                name='unique_fks_academic_year_fk_batch_no_deleted',
                condition=Q(is_deleted=False),
            ),
            models.UniqueConstraint(
                fields=['fk_batch','level'],
                name='unique_level_fk_batch_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]


class StudentLevel(SoftDeleteModel):
    fk_student_batch = models.ForeignKey('StudentBatch',verbose_name = _("Student"), on_delete=models.CASCADE,related_name='level_set')
    fk_level = models.ForeignKey(Level,verbose_name = _("Level"), on_delete=models.CASCADE,related_name='student_set')
    is_active = models.BooleanField(default=True,verbose_name=_("Is Active"))
    estimate = models.PositiveSmallIntegerField(verbose_name=_("Estimate"),null=True, blank=True)
    avg = models.FloatField(verbose_name=_("Average"),null=True, blank=True)
    total_grade = models.FloatField(verbose_name=_("Total Grade"),null=True, blank=True)
    card_has_preinted = models.BooleanField(default=False,verbose_name=_("Card Has Preinted"))
    student_level_status = models.PositiveSmallIntegerField(
        choices=LevelStudentStatusChoice.choices,
        default=1,
        verbose_name=_("Student Level Status")
    )