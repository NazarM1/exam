
from django.db import models

from DRFBaselCoreU.usermanager.models.User import User
from .ExamHall import ExamHall

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class Monitors(SoftDeleteModel):
     fk_exam_hall = models.ForeignKey(ExamHall, related_name='monitors', on_delete=models.CASCADE,verbose_name =_("Exam Hall"))
     date = models.DateTimeField(verbose_name=_("Date"))
     fk_user = models.ForeignKey(User, on_delete=models.CASCADE,verbose_name=_("Custom User"))

     def __str__(self):
          return f'{self.fk_user}'

     class Meta:
          verbose_name=_("Monitor")
          verbose_name_plural=_("Monitors")
