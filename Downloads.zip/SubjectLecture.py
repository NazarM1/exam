
from django.db import models
from django.db.models import Q
from .SemesterSubject import SemesterSubject
from system_management.models.Grouping import GroupingType
from django.utils.translation  import gettext_lazy as _
from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel



class SubjectLecture(SoftDeleteModel):
    fk_semester_subject = models.ForeignKey(SemesterSubject,related_name='subject_lectures',on_delete=models.CASCADE,verbose_name=_("Semestet Subject"))
    fk_lecture_type = models.ForeignKey(GroupingType,related_name='subject_lectures',on_delete=models.CASCADE,verbose_name=_("Lecture Type"))
    lecture_no = models.PositiveSmallIntegerField(verbose_name=_("Lecture No"))
    # for_lab = models.BooleanField(default=False,verbose_name=_("For Lab"))
    
    def __str__(self):
        return f' {self.id} - {self.lecture_no} - {self.fk_semester_subject}'
    
    class Meta:
        verbose_name =_("Subject Lecture")
        verbose_name_plural =_("Subject Lectures")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_semester_subject','lecture_no','fk_lecture_type'],
                name="lecture_constaints",
                condition=Q(is_deleted=False))
        ]