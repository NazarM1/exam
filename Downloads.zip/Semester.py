
from django.db import models
from system_management.choices.choices import SemesterChoice
from django.db.models import Q
from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel

from django.utils.translation  import gettext_lazy as _
from .Level import Level

class Semester(SoftDeleteModel):
    fk_level = models.ForeignKey(Level,verbose_name =_("المستوى"),related_name='semester_set',on_delete=models.PROTECT)
    name = models.PositiveSmallIntegerField(choices=SemesterChoice.choices,verbose_name=_("Semester Name"))
    is_current = models.BooleanField(default=False,verbose_name=_("Is Current"))
    is_locked = models.BooleanField(default=False,verbose_name=_("Is Locked"))
    is_last_semester_for_level = models.BooleanField(default=False,verbose_name=_('اخر فصل للمستوى'))

    def __str__(self):
        return self.name

    class Meta:
        verbose_name=_("Semester")
        verbose_name_plural=_("Semesters")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_level','name'],
                name='unique_fk_level_4b_name_deleted',
                condition=Q(is_deleted=False)
            ),
            models.UniqueConstraint(
                fields=['is_current','fk_level'],
                condition=Q(Q(is_deleted=False),Q(is_current=True)),
                name='unique_is_current_fk_level_4b_deleted'
            ),
            models.UniqueConstraint(
                fields=['is_last_semester_for_level','fk_level'],
                condition=Q(Q(is_deleted=False),Q(is_current=True)),
                name='unique_is_last_semester_for_level_fk_level_4b_deleted'
            )
        ]


