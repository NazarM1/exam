from django.db import models
from django.core.validators import RegexValidator

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class Guardian(SoftDeleteModel):
    guardian_name = models.CharField(max_length=100,verbose_name=_("اسم ولي الأمر"))
    guardian_profession = models.CharField(max_length=100,verbose_name=_("مهنة ولي الأمر"),null=True,blank=True)
    guardian_workplace = models.CharField(max_length=100,verbose_name=_("جهة عمل ولي الأمر"),null=True,blank=True)
    guardian_relationship = models.CharField(max_length=50,verbose_name=_("صلة القرابة"),null=True,blank=True)
    guardian_work_phone = models.CharField(max_length=20,validators=[RegexValidator(r'^\+?[0-9]{8,15}$')],verbose_name=_("رقم تلفون عمل ولي الأمر"),null=True,blank=True)
    guardian_address = models.TextField(verbose_name=_("عنوان ولي الأمر"),null=True,blank=True)
    
    # First Reference
    reference1_name = models.CharField(max_length=100,verbose_name=_("المعرف الأول"),null=True,blank=True)
    reference1_phone = models.CharField(max_length=20,validators=[RegexValidator(r'^\+?[0-9]{8,15}$')],verbose_name=_("رقم تلفون المعرف الأول"),null=True,blank=True)
    
    # Second Reference
    reference2_name = models.CharField(max_length=100,verbose_name=_("المعرف الثاني"),null=True,blank=True)
    reference2_phone = models.CharField(max_length=20,validators=[RegexValidator(r'^\+?[0-9]{8,15}$')],verbose_name=_("رقم تلفون المعرف الثاني"),null=True,blank=True)

    class Meta:
        verbose_name = _("وولي الأمر")
        verbose_name_plural = _("وأولياء الأمور")

    def __str__(self):
        return f"{self.guardian_name} - {self.guardian_relationship}"