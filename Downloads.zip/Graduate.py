from django.db import models
from system_management.models.AcademicYear import AcademicYear
from student_affairs.models.StudentBatch import StudentBatch
from django.db.models import Q


from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class Graduate(SoftDeleteModel):
     fk_student_batch = models.ForeignKey(StudentBatch, related_name='graduate', on_delete=models.PROTECT,verbose_name=_("Student"))
     fk_graduation_year = models.ForeignKey(AcademicYear,related_name="graduate_student",on_delete=models.PROTECT,verbose_name=_("Academic Year"))
     cumulative_gpa = models.PositiveSmallIntegerField(verbose_name=_("Cumulative GPA"),blank=True, null=True)
     certificate_no = models.CharField(max_length=12,verbose_name=_("Certificate No"))
     disclaimer = models.BooleanField(default=False,verbose_name=_("Disclaimer"))
     with_honour = models.BooleanField(default=False,verbose_name=_("With Honour"))
     certificate_issue_date = models.DateField(auto_now_add=True,verbose_name=_("Certificate Issue Date"))
     cumulative_total = models.PositiveSmallIntegerField(verbose_name=_("Cumulative Total"))
     cumulative_grade = models.CharField(max_length=8,verbose_name=_("Cumulative Grade"))
     
     
     def __str__(self):
          return f'{self.fk_student_batch} - {self.certificate_no}'
     class Meta:
          verbose_name=_("Graduate")
          verbose_name_plural =_("Graduates")
          constraints = [
               models.UniqueConstraint(
                    fields=['fk_student_batch'],
                    name='unique_fk_student__deleted',
                    condition=Q(is_deleted=False),
               )
          ]