from django.db import models

from .ExamHall import ExamHall
from .ExamSchedule import ExamSchedule
from .ConflictExamSchedule import ConflictExamSchedule

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel, models
from django.utils.translation  import gettext_lazy as _



#  ربط اللجان بجدول الامتحانات
class ExamScheduleHall(SoftDeleteModel):
     fk_exam_schedule = models.ForeignKey(ExamSchedule,related_name='esh_exam_schedule',on_delete =models.CASCADE,verbose_name=_("Exam Schedule"))
     fk_exam_hall     = models.ForeignKey(ExamHall,related_name='esh_exam_hall',on_delete =models.CASCADE,verbose_name=_("Exam Hall"))

     class Meta:
          verbose_name=_("Exam Schedule Hall")
          verbose_name_plural =_("Exam Schedule Halls")

class ConflictExamScheduleHall(SoftDeleteModel):
     fk_conflict_exam_schedule = models.ForeignKey(ConflictExamSchedule,related_name='esh_exam_schedule',on_delete =models.CASCADE,verbose_name=_("Conflict Exam Schedule"))
     fk_exam_hall     = models.ForeignKey(ExamHall,related_name='esh_conflict_exam_hall',on_delete =models.CASCADE,verbose_name=_("Conflict Exam Hall"))

     class Meta:
          verbose_name=_("Conflict Exam Schedule Hall")
          verbose_name_plural =_("Conflict Exam Schedule Halls")
