
from django.db import models
from .Batch import Batch
from DRFBaselCoreU.common.models.Branch import Organization

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _
from django.db.models import Q


class BatchBranch(SoftDeleteModel):
    fk_batch = models.ForeignKey(Batch, on_delete=models.PROTECT,verbose_name = _("Batch"))
    fk_branch = models.ForeignKey(Organization, on_delete=models.PROTECT,verbose_name=_("Branch"),null=True, blank=True)
    state = models.BooleanField(default=True)
    
    def __str__(self):
        return f'{self.fk_batch.batch_no} - {self.fk_branch.name_ar}'
    class Meta:
        verbose_name=_("Batch Branch")
        verbose_name_plural=_("Batch Branches")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_batch','fk_branch'],
                name='unique_fk_batch_fk_branch_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]

