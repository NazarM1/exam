
from django.db import models
from academic_affairs.models.SemesterSubject import SemesterSubject
from django.db.models import Q
from ..models.ExamHall import ExamHall
from system_management.choices.choices import DayChoice
from datetime import datetime

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

#  جدول الاختبارات 
class ExamSchedule(SoftDeleteModel):
     fk_semester_subject = models.ForeignKey(SemesterSubject, related_name='exam_schedule', on_delete=models.CASCADE,verbose_name=_("Semester Subject"))
     fk_exam_date = models.DateField(verbose_name=_("Exam Date"))
     fk_preiod = models.ForeignKey("Period4Exam",on_delete=models.PROTECT,related_name="exam_schedule",verbose_name=_("Period 4Exam"))
     halls = models.ManyToManyField(ExamHall,through="ExamScheduleHall",verbose_name=_("Exam Hall"))

     def __str__(self):
          return f'{self.fk_semester_subject}'
          
     class Meta:
          verbose_name=_("Exam Schedule")
          verbose_name_plural =_("Exam Schedules")
          constraints = [
               models.UniqueConstraint(
                    fields=['fk_semester_subject','fk_exam_date','fk_preiod'],
                    name='unique_fk_semester_subject_4b_fk_exam_date_fk_preiod_no_deleted',
                    condition=Q(is_deleted=False),
               )
          ]

     def get_day_name(self):
          name = self.fk_exam_date.strftime('%A')
          return _(name)

     def get_day(self):
          name  = DayChoice.get_value(_(self.fk_exam_date.strftime('%A')))
          return name


