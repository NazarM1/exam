

from django.db import models
from system_management.choices.choices import StudyTypeChoice,StudentStatusChoice,GenderChoice,BloodTypeChoice
from .Guardian import Guardian
from system_management.models.TypeOfHighSchool import TypeOfHighSchool
from system_management.models.AcademicYear import AcademicYear
from DRFBaselCoreU.usermanager.models.User import User
from django.db.models import Q
from DRFBaselCoreU.common.models.Address import Address
from DRFBaselCoreU.common.models.Branch import Organization
from DRFBaselCoreU.common.models.Archive import Archive
from DRFBaselCoreU.common.models.Country import Country

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _



class Student(SoftDeleteModel):
     fk_branch = models.ForeignKey(Organization, related_name='students_in_branch', on_delete=models.PROTECT,null=True, blank=True)
     
     # بيانات اساسيه 
     fk_user = models.ForeignKey(User, related_name='student', on_delete=models.PROTECT,verbose_name=_('Custom User'))
     full_name_ar = models.CharField(max_length=100,verbose_name=_('Full Name (Arabic)'))
     full_name_en = models.CharField(max_length=100, blank=True, null=True,verbose_name=_('Name (English)'))
     gender = models.PositiveSmallIntegerField(choices=GenderChoice.choices,default=GenderChoice.MALE,verbose_name=_("Gender"))
     fk_address  = models.ForeignKey(Address, related_name='student_address', on_delete=models.PROTECT,verbose_name=_("Address"))
     fk_place_of_brith  = models.ForeignKey(Address, related_name='student_place_of_brith', on_delete=models.PROTECT,blank=True, null=True,verbose_name=_("Place of Brith"))
     date_of_birth = models.DateField(blank=True,null=True,verbose_name=_("Date of Brith"))
     fk_ssn_archive = models.ForeignKey(Archive,on_delete=models.SET_NULL,null=True,blank=True,verbose_name=_("Archive"))
     fk_nationality = models.ForeignKey(Country,on_delete=models.SET_NULL,null=True,blank=True,verbose_name=_("Nationality Name (Arabic)")) 
     blood_type = models.PositiveSmallIntegerField(choices=BloodTypeChoice.choices,null=True,blank=True,default=BloodTypeChoice.A_POSITIVE,verbose_name=_("Blood Type"))
     
     
     # بيانات الاتصال + email
     mobile_no = models.CharField(max_length=15,verbose_name=_("Mobile No"))
     phone_no = models.CharField(max_length=15,blank=True,null=True,verbose_name=_("Phone No"))
     can_login_to_gate = models.BooleanField(default=False,verbose_name=_('تمكين الطالب من الدخول للبوابة'))

     # بينات الثانوية العامه
     school = models.CharField(max_length=100,null=True,blank=True,verbose_name=_("اسم المدرسة"))
     fk_qualification_address  = models.ForeignKey(Address, related_name='student_qualification_address', on_delete=models.PROTECT,blank=True, null=True,verbose_name=_("عنوان المؤهل"))
     fk_type_of_high_school = models.ForeignKey(TypeOfHighSchool, related_name='student_data', on_delete=models.CASCADE,verbose_name=_("نوع الثانوية"))
     student_grade = models.PositiveBigIntegerField(verbose_name=_("درجة الطالب"))
     final_grade = models.PositiveBigIntegerField(verbose_name=_("الدرجة النهائية"))
     grade_point_average = models.DecimalField(max_digits=10,decimal_places=2,verbose_name=_("معدل الطالب"))
     the_year = models.CharField(max_length=9,verbose_name =_("عام التخرج"))
     seat_no = models.PositiveBigIntegerField(verbose_name=_("Seat No"))
     
     # بيانات ولي الامر 
     fk_guardian  = models.ForeignKey(Guardian, related_name='student', on_delete=models.PROTECT,verbose_name=_('Guardian'),null=True,blank=True)

     #البيانات الاكاديمية
     academice_no = models.CharField(max_length=20  ,blank=True, null=True ,verbose_name=_('Academice No'))
     student_status = models.PositiveSmallIntegerField(choices=StudentStatusChoice.choices,verbose_name=_('Student Status'))
     fk_enrollment_year = models.ForeignKey(AcademicYear, related_name='students', on_delete=models.PROTECT,verbose_name=_('Enrollment Year'))
     clipboard_no_acadmic = models.CharField(max_length=15, verbose_name=_('Clipboard no'),null=True,blank=True) # هذه الحافظة لدفع رسوم الدراسيه
     study_type = models.IntegerField(blank=True, null=True,choices=StudyTypeChoice,verbose_name=_('النظام الدراسي'))
     
     
     def __str__(self):  
          return self.full_name_ar
          
     class Meta:
          verbose_name =_('Student')
          verbose_name_plural =_('Students')       
          constraints = [
               models.UniqueConstraint(
                         fields=['fk_user'],
                         name='unique_fk_user__deleted',
                         condition=Q(is_deleted=False),
               ),
               models.UniqueConstraint(
                    fields=['academice_no'],
                    name='unique_academice_no_deleted',
                    condition=Q(is_deleted=False),
               )
          ] 