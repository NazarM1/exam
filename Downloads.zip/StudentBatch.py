from django.db import models
from django.db.models import Q

from academic_affairs.models.Batch import Batch
from system_management.choices.choices import AcademicStatusChoice
from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from .Student import Student
from DRFBaselCoreU.common.models.Branch import Organization
from django.utils.translation  import gettext_lazy as _
from system_management.models.AcademicYear import AcademicYear
from system_management.models.StudeySystem import StudySystem
class StudentBatch(SoftDeleteModel):
     fk_student = models.ForeignKey(Student, related_name='student_batch', on_delete=models.CASCADE, verbose_name =_('Student'))
     fk_academic_year = models.ForeignKey(AcademicYear,verbose_name=_("Academic Year"), related_name='student_batch_set', on_delete=models.PROTECT)
     fk_previous_batch = models.ForeignKey('self',on_delete=models.PROTECT,null=True,blank=True,related_name="children", verbose_name =_('Previous Batch'))
     fk_batch = models.ForeignKey(Batch, related_name='students', on_delete=models.PROTECT,verbose_name=_('Batch'))
     accademic_status = models.PositiveSmallIntegerField(choices=AcademicStatusChoice.choices,verbose_name=_('Accademic Status'))
     is_current = models.BooleanField(verbose_name=_("Is Current"))
     number_based_on_status = models.CharField(max_length=10,null=True,blank=True,verbose_name=_('Number Based On Status'))
     fk_Study_system = models.ForeignKey(StudySystem, related_name='students', on_delete=models.PROTECT,verbose_name=_('النظام الدراسي'),null=True, blank=True)
     fk_branch = models.ForeignKey(Organization, related_name='students', on_delete=models.PROTECT,verbose_name=_('Branch'),null=True, blank=True)

     def __str__(self):
          return f'{self.fk_student} - {self.fk_batch}'

     class Meta:
          verbose_name =_('Student Batch')
          verbose_name_plural =_('Student Batches')
          constraints = [
               models.UniqueConstraint(
                    fields=['fk_student','fk_batch','fk_branch','fk_previous_batch'],
                    name='unique_fk_student_fk_batch_no_deleted',
                    condition=Q(is_deleted=False) & Q(fk_previous_batch__isnull=False),
               ),
               models.UniqueConstraint(
                    fields=['fk_student','fk_batch','fk_branch'],
                    name='unique_fk_student_fk_batch_fk_branch_fk_previous_batch__isnull_no_deleted',
                    condition=Q(is_deleted=False) & Q(fk_previous_batch__isnull=True),
               ),
               models.UniqueConstraint(
                    fields=['fk_student'],
                    name='unique_fk_student_is_current_no_deleted',
                    condition=Q(is_deleted=False) & Q(is_current=True),
               )
          ]

     def get_first_node(self):
          if self.fk_previous_batch is None:
               return self
          return self.fk_previous_batch.get_first_node()

     def get_last_node(self):
          if not self.children.exists():
               return self
          return self.children.last().get_last_node()
