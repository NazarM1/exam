
from django.db import models
from .Semester import Semester
from django.db.models import Q



from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class Period4Schedule(SoftDeleteModel):
    fk_semester = models.ForeignKey(Semester, related_name="periods",on_delete=models.CASCADE, verbose_name=_("Semester"))
    time_from = models.TimeField(verbose_name=_("Time From"))
    time_to = models.TimeField(verbose_name=_("Time To"))
    order_no = models.PositiveSmallIntegerField(verbose_name=_("Order No"))

    def __str__(self):
        return f'{self.order_no}'
    
    class Meta:
        verbose_name = _("Period 4 Schedule")
        verbose_name_plural = _("Period 4 Schedules")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_semester','order_no'],
                name='unique_fk_semester_group_4b_order_no_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]