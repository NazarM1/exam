from django.db import models
from django.db.models import Q

from student_affairs.models.StudentCourse import StudentSemester
from .ExamScheduleHall import ExamScheduleHall

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _



class StudentExamScheduleHall(SoftDeleteModel):
     fk_student_semester = models.ForeignKey(StudentSemester,related_name='sad_student_academic_data',on_delete =models.CASCADE,verbose_name=_('Student'))
     fk_exam_schedule_hall    = models.ForeignKey(ExamScheduleHall,related_name='sesh_exam_schedule_hall',on_delete =models.CASCADE,verbose_name=_('Exam Schedule Hall'))

     class Meta:
          verbose_name =_('Student Exam Schedule Hall')
          verbose_name_plural =_('Student Exam Schedule Halls')
          constraints = [
               models.UniqueConstraint(
                    fields=['fk_student_semester','fk_exam_schedule_hall'],
                    name='unique_fk_student_fk_exam_schedule_hall_no_deleted',
                    condition=Q(is_deleted=False),
               )
          ]