
from django.db import models
from django.db.models import Q

from system_management.choices.choices import PrepareChoice
from system_management.models.Hall import Hall
from .Period4Schedule import Period4Schedule
from .SubjectLecture import SubjectLecture

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class DailySchedule(SoftDeleteModel):
    fk_subject_lecture = models.ForeignKey(SubjectLecture,related_name='dialy_schedules',on_delete=models.CASCADE,verbose_name=_("Subject Lecture 4B"))
    fk_period_4_schedule = models.ForeignKey(Period4Schedule,related_name='dialy_schedule',on_delete=models.PROTECT,verbose_name=_("Period 4 Schedule"))
    fk_hall = models.ForeignKey(Hall,related_name='dialy_schedule',on_delete=models.PROTECT,verbose_name=_("Hall"))
    fk_teacher = models.ForeignKey("employee_affairs.Employee",related_name='dialy_schedule',on_delete=models.CASCADE,verbose_name=_("Teacher"))
    date = models.DateField(verbose_name="Date")
    teacher_attendance_state = models.PositiveSmallIntegerField(choices=PrepareChoice.choices,verbose_name=_("Teacher Attendance State"))

    def __str__(self):
        return str(self.fk_subject_lecture)
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['fk_period_4_schedule','fk_teacher','date'], name="daily_teacher_constraint", condition=Q(is_deleted=False)),
            models.UniqueConstraint(fields=['fk_period_4_schedule','date','fk_hall'], name="daily_hall_constraint", condition=Q(is_deleted=False)),
            models.UniqueConstraint(fields=['fk_period_4_schedule','date'], name="daily_day_constraint", condition=Q(is_deleted=False)),
        ]
        verbose_name =_("Daily Schedule")
        verbose_name_plural =_("Daily Schedules")

    def get_day_name(self):
        name = self.date.strftime('%A')
        return _(name)