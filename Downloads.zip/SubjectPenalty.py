
from django.db import models
from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _
from system_management.choices.choices import PenaltyActionType, BanScope
from student_affairs.models.StudentCourse import StudentSubject
from django.db.models import Q
from student_affairs.models.StudentCourse import StudentSemester


# عقوبات الطالب في المواد
class SubjectPenalty(SoftDeleteModel):
    fk_student_semester = models.ForeignKey(StudentSemester,related_name='penalties',on_delete =models.CASCADE,verbose_name=_('Student'))
    scope = models.PositiveSmallIntegerField(choices=BanScope.choices,verbose_name=_("نطاق الحظر"))
    reason = models.TextField(verbose_name=_("سبب العقوبة"))
    action_date = models.DateTimeField(verbose_name=_("تاريخ ادخال العقوبة"))
    ban_duration_start = models.PositiveIntegerField(help_text=_("عدد السنوات للحظر"),verbose_name=_("عدد السنوات للحظر"),null=True,blank=True)
    active = models.BooleanField(default=True,verbose_name=_("نشط"))
    
    class Meta:
        verbose_name = _("Subject Penalty")
        verbose_name_plural = _("Subject Penalty")

class SubjectPenaltyItem(SoftDeleteModel):
    fk_penalty = models.ForeignKey(SubjectPenalty, related_name='items', on_delete=models.CASCADE,verbose_name=_("العقوبة"))
    action_type = models.PositiveSmallIntegerField(choices=PenaltyActionType.choices,verbose_name=_("نوع المخالفة"))
    fk_student_subject = models.ForeignKey(StudentSubject,related_name="subject_penalty_item", on_delete=models.CASCADE,verbose_name=_("المواد المحظورة"))

    class Meta:
        verbose_name = _("Subject Penalty Item")
        verbose_name_plural = _("Subject Penalty Item")
        constraints = [
            models.UniqueConstraint(
                    fields=['fk_penalty','fk_student_subject'],
                    name='unique_fk_penalty_fk_student_subject_no_deleted',
                    condition=Q(is_deleted=False),
            )
        ]


