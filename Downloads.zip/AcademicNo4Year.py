from django.db import models
from django.utils.translation  import gettext_lazy as _
from django.db.models import Q

from system_management.models.AcademicSystem import AcademicSystem
from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel, models
from .Batch import Batch

class AcademicNo4Batch(SoftDeleteModel):
    fk_batch = models.ForeignKey(Batch,on_delete=models.CASCADE, verbose_name=_("Batch"))
    fk_academic_no = models.ForeignKey(AcademicSystem,on_delete=models.CASCADE, verbose_name=_("Academic No"))
    order = models.PositiveSmallIntegerField(verbose_name=_("Order"))

    def __str__(self):
            return str(self.order)

    class Meta:
        verbose_name=_("Academic No4 Year") 
        verbose_name_plural =_("Academic No4 Years")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_batch','fk_academic_no'],
                name='unique_fk_batch_fk_academic_no_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]


        
