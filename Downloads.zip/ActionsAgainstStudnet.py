

from django.db import models
from .StudentCourse import StudentSemester
from system_management.models.Action import Action

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _
from django.utils.timezone import localtime

#  العقوبات للطالب  
class ActionsAgainstStudnet(SoftDeleteModel):
     reason = models.TextField(max_length=1500,verbose_name=_("Reason"))
     fk_action = models.ForeignKey(Action, related_name='students', on_delete=models.PROTECT,verbose_name=_("Action"))
     fk_student_semester = models.ForeignKey(StudentSemester, related_name='actions', on_delete=models.CASCADE,verbose_name=_("Student Semester Group"))
     action_date = models.DateTimeField(auto_now_add=True,verbose_name=_("Action Date"))

     def __str__(self):
          return f'{self.fk_student_semester} - {self.fk_action}'
     
     @property 
     def action_date_iso(self):
          return localtime(self.action_date).isoformat()

     class Meta:
          verbose_name =_("Actions Against Studnet")
          verbose_name_plural =_("Actions Against Studnets")



