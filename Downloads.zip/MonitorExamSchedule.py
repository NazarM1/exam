
from django.db import models

from .ExamSchedule import ExamSchedule
from .Monitors import Monitors


from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class MonitorExamSchedule(SoftDeleteModel):
     fk_exam_schedule = models.ForeignKey(ExamSchedule, related_name='exam_schedule_moniter', on_delete=models.CASCADE,verbose_name=_("Exam Schedule"))
     fk_monitor       = models.ForeignKey(Monitors, related_name='monitor_exam_schedule', on_delete=models.CASCADE,verbose_name=_("Monitor"))

     class Meta:
          verbose_name =_("Monitor Exam Schedule")
          verbose_name_plural =_("Monitor Exam Schedules")
     