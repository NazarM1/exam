

from django.db import models
from django.db.models import Q
from system_management.models.AcademicYear import AcademicYear

from system_management.models.Hall import Hall

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class ExamHall(SoftDeleteModel):
     fk_hall = models.ForeignKey(Hall,on_delete=models.PROTECT,related_name="exam_hall",verbose_name=_("Hall"))
     number_of_student = models.PositiveSmallIntegerField(verbose_name=_("Number Of Student"))
     name_ar = models.CharField(max_length=20,verbose_name=_("Name (Arabic)"))
     name_en = models.CharField(max_length=20,blank=True, null=True,verbose_name=_("Name (English)"))
     note = models.TextField(blank=True, null=True,verbose_name=_("Note"))

     def __str__(self):
          return f'{self.fk_hall}'
 
     class Meta:
          verbose_name = _("Exam Hall")
          verbose_name_plural = _("Exam Halls")
          constraints = [
               models.UniqueConstraint(
                    fields=['fk_hall'],
                    name='unique_fk_hall__deleted',
                    condition=Q(is_deleted=False)
               )
          ]
