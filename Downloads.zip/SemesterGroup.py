
from django.db import models
from django.db.models import Q

from system_management.models.Grouping import Grouping
from .Semester import Semester

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class SemesterGroup(SoftDeleteModel):
    fk_semester = models.ForeignKey(Semester, related_name="groups",on_delete=models.PROTECT,verbose_name=_("Semester"))
    fk_grouping = models.ForeignKey(Grouping, related_name="semesters",on_delete=models.PROTECT,verbose_name=_("Grouping"))
    state = models.BooleanField(default=True)

    def __str__(self):
        return str(self.id)

    class Meta:
        verbose_name=_("Semester Group")
        verbose_name_plural=_("Semester Groups")
        constraints = [
            models.UniqueConstraint(
                fields = ['fk_semester','fk_grouping'],
                name = 'unique_fk_semester_4b_fk_grouping_no_deleted',
                condition = Q(is_deleted=False),
            )
        ]