
from django.db import models

from DRFBaselCoreU.usermanager.models.User import User
from student_affairs.models.StudentCourse import GradesRecord

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _
from system_management.choices.choices import RecordChengeGrade

class GradesLog(SoftDeleteModel):
     fk_grade_record = models.ForeignKey(GradesRecord,related_name='grades_log_grades_record',on_delete =models.CASCADE,verbose_name =_("Grades Record"))
     fk_user         = models.ForeignKey(User,related_name='grades_log_user',on_delete=models.CASCADE,verbose_name=_("Custom User"))
     grade_before           = models.DecimalField(max_digits=5,decimal_places=1,verbose_name=_("Grade"))
     grade_after           = models.DecimalField(max_digits=5,decimal_places=1,verbose_name=_("Grade"))
     changed_when = models.PositiveSmallIntegerField(choices=RecordChengeGrade.choices,verbose_name=_("سبب التغيير"))
     date            = models.DateTimeField(verbose_name=_("Date"))

     class Meta:
          verbose_name =_("Grades Log")
          verbose_name_plural =_("Grades Logs")
 