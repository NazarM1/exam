
from django.db import models
from django.db.models import Q

from system_management.models.Hall import Hall
from .SemesterSubject import SemesterSubject
from .Period4Schedule import Period4Schedule


from system_management.choices.choices import DayChoice


from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _
from .SemesterGroup import SemesterGroup

class Schedules(SoftDeleteModel):
    fk_semester_subject = models.ForeignKey(SemesterSubject,related_name='schedules_set',on_delete=models.PROTECT,verbose_name=_("Semester Subject"))
    fk_period_4_schedule = models.ForeignKey(Period4Schedule,related_name='schedules_set',on_delete=models.PROTECT,verbose_name=_("Period 4 Schedule"))
    fk_hall = models.ForeignKey(Hall,related_name='schedules_4b',on_delete=models.PROTECT,verbose_name=_("Hall"))
    fk_teacher = models.ForeignKey("employee_affairs.Employee",related_name='schedules_set',on_delete=models.PROTECT,verbose_name=_("Teacher"))
    day = models.PositiveSmallIntegerField(choices=DayChoice.choices,verbose_name=_("Day"))
    
    groups = models.ManyToManyField(SemesterGroup,verbose_name=_("Groups"))

    def __str__(self):
        return str(self.fk_period_4_schedule)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['fk_period_4_schedule','fk_teacher','day'],name="teacher_constraint", condition=Q(is_deleted=False)),
            models.UniqueConstraint(fields=['fk_period_4_schedule','day','fk_hall'],name="hall_constraint", condition=Q(is_deleted=False)),
            models.UniqueConstraint(fields=['fk_period_4_schedule','day'],name="day_constraint", condition=Q(is_deleted=False)),
        ]
        verbose_name=_("Schedule")
        verbose_name_plural =_("Schedules")