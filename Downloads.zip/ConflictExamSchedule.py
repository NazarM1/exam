
from django.db import models
from academic_affairs.models.SemesterSubject import SemesterSubject


from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel, models
from django.utils.translation  import gettext_lazy as _
from ..models.ExamHall import ExamHall

# للتعارض جدول الاختبارات 
class ConflictExamSchedule(SoftDeleteModel):
     fk_semester_subject = models.ForeignKey(SemesterSubject, related_name='conflict_exam_schedule', on_delete=models.CASCADE,verbose_name=_("Semester Subject"))
     fk_exam_date = models.DateField(verbose_name=_("Exam Date"))
     fk_preiod = models.ForeignKey("Period4Exam",on_delete=models.PROTECT,related_name="conflict_exam_schedule",verbose_name=_("Period 4Exam"))
     halls = models.ManyToManyField(ExamHall,through="ConflictExamScheduleHall",verbose_name=_("Exam Hall"))

     def __str__(self):
          return f'{self.fk_semester_subject_4b}'

     class Meta:
          verbose_name=_("Conflict Exam Schedule")
          verbose_name_plural =_("Conflict Exam Schedules")