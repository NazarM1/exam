
from django.db import models
from django.db.models import Q

from system_management.models.GradingSystem import GradingSystem
from system_management.models.Subject import Subject
from .Semester import Semester

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _
from system_management.models.Grouping import GroupingType




class SemesterSubject(SoftDeleteModel):
    fk_semester = models.ForeignKey(Semester, related_name="subjects",on_delete=models.PROTECT,verbose_name=_("Semester"))   
    fk_subject = models.ForeignKey(Subject, related_name="semester_subjects",on_delete=models.PROTECT,verbose_name=_("Subject"))  
    fk_grading_system_june = models.ForeignKey(GradingSystem,related_name='semestersubject_june',on_delete=models.PROTECT,verbose_name=_('لنظام الدرجات للملتحقين بنظام العام'))
    fk_grading_system_october = models.ForeignKey(GradingSystem,related_name='semestersubject_october',on_delete=models.PROTECT,verbose_name=_('لنظام الدرجات للملتحقين بدور اكتوير'))
    fk_grading_system_exempted = models.ForeignKey(GradingSystem,related_name='semestersubject_exempted',on_delete=models.PROTECT,verbose_name=_('لنظام الدرجات للمعفيين '))
    fk_grading_system_withdrawn = models.ForeignKey(GradingSystem,related_name='semestersubject_withdrawn',on_delete=models.PROTECT,verbose_name=_('لنظام الدرجات للمتنازلين '),null=True,blank=True)
    number_of_hours = models.PositiveSmallIntegerField(verbose_name=_('Number Of Hours'))    
    is_failed = models.BooleanField(default=True,verbose_name=_('يرسب الطالب في المستوى عند رسوبه في هذه المادة'))
    is_core_subject = models.BooleanField(verbose_name=_("مادة اساسية"),default=True) 

    def __str__(self):
        return f' {self.fk_subject} - {self.fk_semester}'

    class Meta:
        verbose_name=_("Semestet Subject")
        verbose_name_plural=_("Semestet Subjects")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_semester','fk_subject'],
                name='unique_fk_semester_fk_semeter_subject_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]




class SemesterSubjectGroupLecture(SoftDeleteModel):
    fk_semester_subject = models.ForeignKey(SemesterSubject,on_delete=models.CASCADE,verbose_name=_('semester subject'))
    fk_group_type = models.ForeignKey(GroupingType,related_name='semester_subjects',on_delete=models.CASCADE,verbose_name=_('نوع القروب'))
    number_of_lecture = models.PositiveSmallIntegerField(verbose_name=_('number of lectcher'))
    
    def __str__(self):
        return f' {self.fk_semester_subject} - {self.fk_group_type}'

    class Meta:
        verbose_name=_("Semestet Subject")
        verbose_name_plural=_("Semestet Subjects")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_semester_subject','fk_group_type'],
                name='unique_fk_group_type_fk_semeter_subject_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]


