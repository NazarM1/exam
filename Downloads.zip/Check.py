from django.db import models
from django.db.models import Q
from .Student import Student
from system_management.models.RequiredDocument import RequiredDocument
from system_management.models.RequiredCondition import RequiredCondition
from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel, models
from django.utils.translation  import gettext_lazy as _


#   التحقق من الوثائق المطلوبة
class CheckDocument(SoftDeleteModel):
     fk_student = models.ForeignKey(Student, related_name='check_documents', on_delete=models.CASCADE,verbose_name=_('Student Academic Data'))
     fk_required_document = models.ForeignKey(RequiredDocument, related_name='check_documents', on_delete=models.PROTECT,null=True,blank=True,verbose_name=_('Required Document'))
     status = models.BooleanField(default=False,verbose_name=_('Status'))


     def __str__(self):
          return f'{self.fk_student} - {self.status} - {self.fk_required_document}'

     class Meta:
          verbose_name =_('Check Document')
          verbose_name_plural =_('Check Documents')
          constraints = [
               models.UniqueConstraint(
                    fields=['fk_student','fk_required_document'],
                    name='unique_fk_student_fk_required_document_no_deleted',
                    condition=Q(is_deleted=False),
               )
          ]


#   التحقق من الشروط المطلوبة
class CheckCondition(SoftDeleteModel):
     fk_student = models.ForeignKey(Student, related_name='requied_condition', on_delete=models.CASCADE,verbose_name=_('Student Academic Data'))
     fk_required_condition = models.ForeignKey(RequiredCondition, related_name='chek_condition', on_delete=models.PROTECT,blank=True, null=True,verbose_name=_('Required Condition'))
     status = models.BooleanField(default=False,verbose_name=_('Status'))

     def __str__(self):
          return f'{self.fk_student} - {self.status} - {self.fk_required_condition}'
     class Meta:
          verbose_name =_('Check Condition')
          verbose_name_plural =_('Check Conditions')
          constraints = [
               models.UniqueConstraint(
                    fields=['fk_student','fk_required_condition'],
                    name='unique_fk_student_fk_required_condition_no_deleted',
                    condition=Q(is_deleted=False),
               )
          ]