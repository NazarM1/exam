from django.db import models
from django.db.models import Q

from academic_affairs.models.DailySchedule import DailySchedule
from system_management.choices.choices import PrepareChoice
from .StudentCourse import StudentGroup


from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _

class Studentschedules4B(SoftDeleteModel):
     fk_student_group = models.ForeignKey(StudentGroup, related_name='scedules', on_delete=models.CASCADE,verbose_name=_('Student'))
     fk_dialy_schedule = models.ForeignKey(DailySchedule,verbose_name=('Daily Schedule'),on_delete=models.PROTECT,related_name="students")
     status = models.PositiveSmallIntegerField(choices=PrepareChoice.choices,blank=True, null=True,verbose_name=_('Status'))

     def __str__(self):
          return f'{self.fk_student_group} - {self.fk_dialy_schedule}'

     class Meta:
          verbose_name =_('Student Schedule 4B')
          verbose_name_plural =_('Student Schedules4B')
          constraints = [
               models.UniqueConstraint(
                    fields=['fk_student_group','fk_dialy_schedule'],
                    name='unique_fk_student_group_fk_dialy_schedule_4b_no_deleted',
                    condition=Q(is_deleted=False),
               )
          ]