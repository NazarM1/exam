from django.db import models
from django.db.models import Q

from system_management.models.AcademicYear import AcademicYear
from system_management.models.College import College
from DRFBaselCoreU.common.models.Branch import Organization
from system_management.models.Specialization import Specialization

from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation  import gettext_lazy as _
from system_management.models.AcademicSystem import AcademicSystem
 
class Batch(SoftDeleteModel):
    fk_specialization = models.ForeignKey(Specialization,verbose_name=_("Specialization"),related_name='batchs',on_delete=models.CASCADE,null=True,blank=True)
    fk_academic_year = models.ForeignKey(AcademicYear,verbose_name=_("Academic Year"), related_name='batchs', on_delete=models.PROTECT)
    batch_no = models.CharField(verbose_name=_("Name (Arabic)"),max_length=50)
    graduates = models.BooleanField(verbose_name=_("Graduates"),default=False)
    
    academic_no = models.ManyToManyField(AcademicSystem,through="AcademicNo4Batch",verbose_name=_("Academic No"))

    branchs = models.ManyToManyField(Organization,through="BatchBranch",verbose_name=_("Branch"))
    def __str__(self):
        return self.batch_no

    class Meta:
        verbose_name = _("Batch")
        verbose_name_plural=_("Batches")
        constraints = [
            models.UniqueConstraint(
                fields=['batch_no'],
                name='unique_batch_code_no_deleted',
                condition=Q(is_deleted=False),
            ),
            models.UniqueConstraint(
                fields=['fk_specialization','fk_academic_year'],
                name='unique_fk_specialization_fk_academic_year_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]