from django.db.models import Count, Case, When, IntegerField, F, Q, Sum
from django.utils import timezone
from django.db.models import Sum
from django.db import models
from django.db.models import Q

from academic_affairs.models.SemesterGroup import SemesterGroup
from system_management.choices.choices import LevelStudentStatusChoice, SemesterStudentStatusChoice, EstimateChoice, SubjectStatusChoice, ResultStatusChoice
from .StudentBatch import StudentBatch
from academic_affairs.models.Level import Level
from academic_affairs.models.Semester import Semester
from system_management.models.Grouping import GroupingType
from academic_affairs.models.SemesterSubject import SemesterSubject
from DRFBaselCoreU.utils.abstract_models.soft_delete_model import SoftDeleteModel
from django.utils.translation import gettext_lazy as _
from system_management.models.ResultsRecordSymbol import ResultsRecordSymbol
from system_management.models.GradeDistribution import GradeDistribution


class AcademicYear(models.Model):
    year_h = models.PositiveSmallIntegerField(
        validators=[MinValueValidator(1400), MaxValueValidator(1800)])
    year_m = models.CharField(max_length=9)
    is_cournt = models.BooleanField(default=False)
    number_of_semesters = models.PositiveSmallIntegerField(default=2)
    vacations_balance = models.PositiveSmallIntegerField(default=14)
    order = models.PositiveSmallIntegerField()


class Batch(models.Model):
    fk_specialization = models.ForeignKey(
        'system_management.Specialization', on_delete=models.PROTECT, related_name="batches"
    )
    fk_academic_year = models.ForeignKey(
        'system_management.AcademicYear', on_delete=models.PROTECT, related_name="batches"
    )
    batch_no = models.CharField(max_length=10)


class StudentBatch(models.Model):
    fk_student = models.ForeignKey(
        'system_management.Student', on_delete=models.PROTECT, related_name="student_batch"
    )
    fk_batch = models.ForeignKey(
        Batch, on_delete=models.PROTECT, related_name="student_batch_set"
    )
    fk_academic_year = models.ForeignKey(
        'system_management.AcademicYear', on_delete=models.PROTECT, related_name="student_batch_set"
    )
    fk_previous_batch = models.ForeignKey(
        "self", on_delete=models.PROTECT, related_name="children", blank=True, null=True
    )
    accademic_status = models.PositiveSmallIntegerField(
        choices=SemesterStudentStatusChoice.choices, verbose_name=_('Academic Status'))
    is_current = models.BooleanField(default=False)
    number_based_on_status = models.CarField(
        max_length=20, blank=True, null=True)
    fk_study_system = models.ForeignKey(
        'system_management.StudySystem', on_delete=models.PROTECT, related_name="students"
    )

    class Meta:
        unique_together = ('fk_student', 'fk_batch')


class SemesterSubject(models.Model):
    fk_semester = models.ForeignKey(
        Semester, on_delete=models.CASCADE, related_name="semester_subjects"
    )
    fk_subject = models.ForeignKey(
        Subject, on_delete=models.CASCADE, related_name="semester_subjects"
    )
    fk_grade_system_june = models.ForeignKey(
        GradeSystem, on_delete=models.CASCADE, related_name="semester_subjects_june"
    )
    fk_grade_system_october = models.ForeignKey(
        GradeSystem,
        on_delete=models.CASCADE,
        related_name="semester_subjects_october",
    )
    fk_grade_system_exempted = models.ForeignKey(
        GradeSystem,
        on_delete=models.CASCADE,
        related_name="semester_subjects_exempted",
    )
    fk_grade_system_withdrawn = models.ForeignKey(
        GradeSystem,
        on_delete=models.CASCADE,
        related_name="semester_subjects_withdrawn",
    )
    number_of_hours = models.PositiveSmallIntegerField()
    is_failed = models.BooleanField(default=False)
    is_core_subject = models.BooleanField(default=False)


class EstimateChoice(models.IntegerChoices):
    POOR = 1, _('ضعيف')
    ACCEPTABLE = 2, _('مقبول')
    GOOD = 3, _('جيد')
    VERY_GOOD = 4, _('جيد جدا')
    EXCELLENT = 5, _('ممتاز')


class ResultStatusChoice(models.IntegerChoices):
    PENDING = 9, _('قيد الانتظار')
    CLEARANCE = 1, _('مقاصة')
    CHEATING = 2, _('غش')
    ABSENCE = 3, _('غياب')
    WITHDRAWN = 4, _('متنازل')
    REPEATER = 5, _('معيد')
    REMAINING = 6, _('مبقي')
    PASSED = 7, _('ناجح')
    DEPRIVATION = 8, _('حرمان')


class StudentLevel(SoftDeleteModel):
    fk_student_batch = models.ForeignKey(
        StudentBatch, related_name='level_set', on_delete=models.CASCADE, verbose_name=_('Student'))
    fk_level = models.ForeignKey(
        Level, on_delete=models.PROTECT, related_name="student_set", verbose_name=_('المستوى'))
    is_active = models.BooleanField(verbose_name=_("Is Active"))

    estimate = models.PositiveSmallIntegerField(
        choices=EstimateChoice.choices, blank=True, null=True, verbose_name=_('Estimate'))
    avg = models.DecimalField(
        max_digits=5, decimal_places=2, blank=True, null=True, verbose_name=_('AVG'))
    total_grade = models.DecimalField(
        max_digits=6, decimal_places=2, blank=True, null=True, verbose_name=_('Total Grade'))
    card_has_preinted = models.BooleanField(
        default=False, verbose_name=_('Card Has Preinted'))
    student_level_status = models.PositiveSmallIntegerField(
        choices=LevelStudentStatusChoice.choices, verbose_name=_('Student Level Status'))

    def __str__(self):
        return f'{self.fk_student_batch} - {self.fk_level}'

    class Meta:
        verbose_name = _('Student Level')
        verbose_name_plural = _('Student Levels')
        constraints = [
            models.UniqueConstraint(
                fields=['fk_student_batch', 'fk_level'],
                name='unique_fk_student_batch_fk_level_no_deleted',
                condition=Q(is_deleted=False),
            ),
        ]


class StudentSemester(SoftDeleteModel):
    fk_student_level = models.ForeignKey(
        StudentLevel, related_name='semester_set', on_delete=models.CASCADE, verbose_name=_('Student'))
    fk_semester = models.ForeignKey(
        Semester, on_delete=models.PROTECT, related_name="student_set", verbose_name=_('المستوى'))
    is_active = models.BooleanField(verbose_name=_("Is Active"))

    estimate = models.PositiveSmallIntegerField(
        choices=EstimateChoice.choices, blank=True, null=True, verbose_name=_('Estimate'))
    avg = models.DecimalField(
        max_digits=5, decimal_places=2, blank=True, null=True, verbose_name=_('AVG'))
    total_grade = models.DecimalField(
        max_digits=6, decimal_places=2, blank=True, null=True, verbose_name=_('Total Grade'))
    fk_exam_hall = models.ForeignKey("control.ExamHall", on_delete=models.PROTECT,
                                     null=True, blank=True, related_name="exam_hall", verbose_name=_('Exam Hall'))
    PIN = models.PositiveSmallIntegerField(
        blank=True, null=True, verbose_name=_('PIN'))
    seating_no = models.PositiveSmallIntegerField(
        blank=True, null=True, verbose_name=_('Seating No'))
    student_semester_status = models.PositiveSmallIntegerField(
        choices=SemesterStudentStatusChoice.choices, verbose_name=_('Student Semester Status'))

    def __str__(self):
        return f'{self.fk_student_level} - {self.fk_semester}'

    class Meta:
        verbose_name = _('Student Level')
        verbose_name_plural = _('Student Levels')
        constraints = [
            models.UniqueConstraint(
                fields=['fk_student_level', 'fk_semester'],
                name='unique_fk_student_level_fk_semester_no_deleted',
                condition=Q(is_deleted=False),
            ),
        ]


class StudentGroup(SoftDeleteModel):
    fk_student_semester = models.ForeignKey(
        StudentSemester, related_name='student_set', on_delete=models.CASCADE, verbose_name=_('Student'))
    fk_semester_group = models.ForeignKey(
        SemesterGroup, on_delete=models.PROTECT, related_name="student_thor_set", verbose_name=_('مجموعة الطالب'))
    fk_grouping_type = models.ForeignKey(
        GroupingType, on_delete=models.CASCADE, verbose_name=_("توع المجموعة"))

    def __str__(self):
        return f'{self.fk_student_semester} - {self.fk_semester_group}'

    class Meta:
        verbose_name = _('Student Semester Group')
        verbose_name_plural = _('Student Semester Groups')
        constraints = [
            models.UniqueConstraint(
                fields=['fk_student_semester', 'fk_grouping_type'],
                name='unique_fk_student2_fk_grouping_type_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]


class Estimate(SoftDeleteModel):
    fk_branch = models.ForeignKey(
        'system_management.Branch', on_delete=models.PROTECT, verbose_name=_("Branch"))
    fk_grading_system = models.ForeignKey(
        GradingSystem, on_delete=models.PROTECT, verbose_name=_("Grading System"))
    name = models.CharField(max_length=100, verbose_name=_("Estimate Name"))
    gte = models.PositiveSmallIntegerField(
        verbose_name=_("Greater Than Or Equal"))
    lt = models.PositiveSmallIntegerField(verbose_name=_("Less Than"))
    description = models.TextField(
        blank=True, null=True, verbose_name=_("Description"))
    displacement_degree = models.FloatField(
        default=0, verbose_name=_("Displacement Degree"))


# مواد الطالب
class StudentSubject(SoftDeleteModel):
    fk_student_semester = models.ForeignKey(
        StudentSemester, related_name='subjects', on_delete=models.PROTECT, verbose_name=_("Student"))
    fk_previous_result = models.ForeignKey('self', related_name='previous_subject',
                                           on_delete=models.PROTECT, blank=True, null=True, verbose_name=_("Previous Result"))

    fk_semmester_subject = models.ForeignKey(
        SemesterSubject, related_name='students_subject', on_delete=models.PROTECT, verbose_name=_("Semester Subject"))
    fk_results_record = models.ForeignKey(ResultsRecordSymbol, related_name='students_subject',
                                          on_delete=models.PROTECT, blank=True, null=True, verbose_name=_("Results Record Symbol FK"))
    total_grade = models.DecimalField(
        max_digits=5, decimal_places=1, blank=True, null=True, verbose_name=_("Total Grade"))
    results_status = models.PositiveSmallIntegerField(
        choices=ResultStatusChoice.choices, blank=True, null=True, verbose_name=_("Results Status"))
    estimate = models.PositiveSmallIntegerField(
        choices=EstimateChoice.choices, blank=True, null=True, verbose_name=_("Estimate"))
    number_of_attendance = models.PositiveSmallIntegerField(
        blank=True, null=True, verbose_name=_("Number Of Attendance"))
    perparatoin_grade = models.DecimalField(
        max_digits=5, decimal_places=1, blank=True, null=True, verbose_name=_("Perparation Grade"))
    adding_results_date = models.DateField(
        blank=True, null=True, verbose_name=_("Adding Results Date"))
    subject_status = models.PositiveSmallIntegerField(
        choices=SubjectStatusChoice.choices, verbose_name=_("Subject Status"))
    secret_no = models.CharField(
        max_length=8, blank=True, null=True, verbose_name=_("Secret No"))

    def __str__(self):
        return f'{self.fk_student_semester} - {self.fk_semmester_subject}'

    class Meta:
        verbose_name = _("Student Subject")
        verbose_name_plural = _("Student Subjects")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_student_semester', 'fk_semmester_subject'],
                name='unique_fk_student_fk_semmester_subject_4b_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]

    def get_first_node(self):
        if self.fk_previous_result is None:
            return self
        return self.fk_previous_result.get_first_node()

    def get_last_node(self):
        if not self.children.exists():
            return self
        return self.children.last().get_last_node()


class GradingSystem(SoftDeleteModel):
    fk_branch = models.ForeignKey('system_management.Branch', related_name='grading_systems',
                                  on_delete=models.CASCADE, verbose_name=_("Branch"))
    name_ar = models.CharField(max_length=100, verbose_name=_("Name AR"))
    name_en = models.CharField(
        max_length=100, blank=True, null=True, verbose_name=_("Name EN"))
    grade_total = models.PositiveSmallIntegerField(
        verbose_name=_("Grade Total"))
    grade_system_type = models.PositiveSmallIntegerField(
        choices=GradeSystemTypeChoices, verbose_name=_("Grade System Type"))
    success_grade = models.PositiveSmallIntegerField(
        verbose_name=_("Success Grade"))
    types = models.ManyToManyField('system_management.TypeOfGrade', through='GradeDistribution',
                                   related_name='grading_systems', verbose_name=_("Types Of Grade"))


class GradeDistribution(SoftDeleteModel):
    fk_grading_system = models.ForeignKey(
        'system_management.GradingSystem', related_name='type_of_grade', on_delete=models.CASCADE, verbose_name=_("Grading System"))
    fk_type_of_grade = models.ForeignKey(
        'system_management.TypeOfGrade', related_name='grading_system', on_delete=models.CASCADE, verbose_name=_("Type Of Grade"))
    grade = models.PositiveSmallIntegerField(verbose_name=_("Grade"))
    is_mandatory = models.BooleanField(
        default=False, verbose_name=_("Is Mandatory"))
    fk_for_lab = models.ForeignKey(
        GroupingType, related_name='grading_system', on_delete=models.CASCADE, verbose_name=_("For Lab"), null=True, blank=True)
    for_attendance_grades = models.BooleanField(
        default=False, verbose_name=_("For Attendance Grades"))


class GradesRecord(SoftDeleteModel):
    fk_student_subject = models.ForeignKey(
        StudentSubject, related_name='grade_record', on_delete=models.CASCADE, verbose_name=_("Student Subject"))
    fk_grade_distributiuon = models.ForeignKey(
        GradeDistribution, related_name='grade_record', on_delete=models.CASCADE, verbose_name=_("Grade Distribution"))
    grade = models.DecimalField(
        max_digits=5, decimal_places=1, verbose_name=_("Grade"), null=True, blank=True)

    def __str__(self):
        return f'{self.fk_student_subject}'

    class Meta:
        verbose_name = _("Grades Record")
        verbose_name_plural = _("Grades Records")
        constraints = [
            models.UniqueConstraint(
                fields=['fk_grade_distributiuon', 'fk_student_subject'],
                name='unique_fk_grade_distributiuon_fk_student_subject_no_deleted',
                condition=Q(is_deleted=False),
            )
        ]

