from django.db import transaction
from academic_affairs.models.Level import Level
from academic_affairs.models.SemesterSubject import SemesterSubject

from student_affairs.models.StudentCourse import StudentLevel, StudentSemester, StudentSubject
from system_management.choices.choices import EstimateChoice, LevelStudentStatusChoice, ResultStatusChoice, SemesterStudentStatusChoice
from django.db.models import Count,F,Q,Sum


class UploadStudentsInLevelService:
    """
        يتم ارسال التخصص و السنة و المستوى
        بعد ذالك يتم احتساب مجموع كل فصل و احتساب المتوسط مع التقدير للطالب في هذا الفصل
        ثالثاً يتم اخذ عدد مواد الرسوب للطالب في الفصلين لي هذا المستوى
        رابعاً : يتم جلب مواد المستويات السابقة لهذا المستوى في كل فصل اللي حالتها (مبقي , محروم,غشاش,غياب)
        ويشوف allowed_failure_subjects في المستوى  اذا كان عدد مواد الرسوب في المستوى الحالي و المستويات السابقة يتم وضع حالة المستوى للطالب راسب

        ملاحظات اضافيه
        يتم تغيير حالة الفصل و المستوى من تحت التسجيل الى مقفل
        و اذا كان الطالب راسب في  ماده واحده او اكثير بشرط عدم تجاوزه للحد المسموح به يتم تسجيله في المستوى مقفل مع حمل مواد
        واذا كان راسب وتجاوز الحد المسموح به يتم تسجيل حالته مقفل للاعادة و بدون ترفيع الطالب للمستوى التالي
    """
    # اذا كانت حالة المستوى للطالب مقفل لا يتم عمل ايش تعديل فيه
    def __init__(self,target_level:Level):
        self.target_level = target_level
        self.batch = target_level.fk_batch
        self.academic_year = target_level.fk_academic_year
        self.allowed_failures = target_level.allowed_failure_subjects


    def calculate_estimate(self,avg):
        if avg >= 90:
            return EstimateChoice.EXCELLENT
        elif avg >= 80:
            return EstimateChoice.VERY_GOOD
        elif avg >= 70:
            return EstimateChoice.GOOD
        elif avg >= 50:
            return EstimateChoice.ACCEPTABLE
        else:
            return EstimateChoice.POOR

    # -----------------------------------
    #  دالة مساعدة لجلب عدد المواد الراسبة من المستويات السابقة
    # مع تتبع سلسلة الأبناء
    # -----------------------------------
    def get_previous_failed_subjects(self,student_batch,current_level_number):
        """
        جلب عدد المواد الراسبة من المستويات السابقة مع مراعاة المواد ذات الأبناء
        """
        previous_levels = StudentLevel.objects.filter(
            fk_student_batch=student_batch,
            fk_level__level__lt=current_level_number,
        ).prefetch_related("semester_set__subjects")
        failed_subjects_count = 0
        processed_subjects = set()
        print(self.target_level)
        print(current_level_number)
        for prev_level in previous_levels:
            print(prev_level.fk_level.level)
            for semester in prev_level.semester_set.all():
                print(semester)
                for subject in semester.subjects.all():
                    print(subject,'-------------')
                    # تجنب معالجة المواد المكررة
                    if subject.id in processed_subjects:
                        continue

                    # الحصول على اخر نتيجة للمادة (سلسة الأبناء)
                    last_result = subject.get_last_node()

                    if last_result.results_status in  [ResultStatusChoice.CHEATING,ResultStatusChoice.ABSENCE,ResultStatusChoice.REMAINING]:
                        failed_subjects_count += 1
                        processed_subjects.add(last_result.id)
                        processed_subjects.add(subject.id)

        return failed_subjects_count


    # -------------------------
    # الدالة الرئيسية لترفيع الطلاب في مستوى معين
    # -------------------------
    def promote_students(self):
        # """
        #     ترفيع الطلاب في المستوى المحدد
        # """
        # try:
            # جلب جميع الطلاب النشطين في هذا المستوى
            student_levels = StudentLevel.objects.filter(
                fk_level=self.target_level,
            ).exclude(student_level_status__in=[LevelStudentStatusChoice.WITHDRAWN,LevelStudentStatusChoice.CLOSED]).select_related("fk_student_batch")


            results = []
            for student_level in student_levels:
                with transaction.atomic():
                    # جلب كل الفصول الخاصة بالطالب
                    student_semesters = StudentSemester.objects.filter(
                        fk_student_level=student_level,
                    ).exclude(student_semester_status__in=[SemesterStudentStatusChoice.WITHDRAWN,SemesterStudentStatusChoice.CLOSED]).prefetch_related("subjects")

                    total_failed_subjects = 0

                    # ---------------------
                    # حساب المجموع و المتوسط لكل فصل
                    # ---------------------
                    level_subject_is_failed = False # هذا المتغير تتغير قيمته  في حالة is_failed True للماده ('يرسب الطالب في المستوى عند رسوبه في هذه المادة')
                    for semester in student_semesters:
                        SemesterSubject.objects.filter()
                        StudentSubject
                        semester_subjects_is_core = 0 # هذا المتغير يتم احتساب عدد المواد الاساسية اللي رسب فيها الطالب في الفصل
                        # ---------------------
                        # المواد الدراسية
                        # ---------------------
                        for subject in semester.subjects.all():
                            if subject.estimate == EstimateChoice.POOR or subject.results_status in [ResultStatusChoice.CHEATING,ResultStatusChoice.ABSENCE,ResultStatusChoice.REMAINING]:
                                if level_subject_is_failed == False:
                                    level_subject_is_failed = subject.fk_semmester_subject.is_failed
                                
                                if subject.fk_semmester_subject.is_core_subject:
                                    semester_subjects_is_core += 1



                        semester_results = semester.subjects.aggregate(
                            total_grade = Sum("total_grade"),
                            failed_count=Count("id",filter=Q(results_status__in=[ResultStatusChoice.CHEATING,ResultStatusChoice.ABSENCE,ResultStatusChoice.REMAINING])),
                            semester_subjects_is_core_total=Count('id',filter=Q(fk_semmester_subject__is_core_subject=True))
                        )
                        subjects_count = semester.subjects.count()
                        total = semester_results['total_grade'] or 0
                        avg = (total / subjects_count) if subjects_count > 0 else 0

                        # تحديث بيانات الفصل
                        semester.total_grade = total
                        semester.avg = avg
                        semester.estimate = self.calculate_estimate(avg)

                        if semester_results['semester_subjects_is_core_total'] == semester_subjects_is_core or subjects_count == semester_results['failed_count']: # رسب في كل المواد الاساسي او جميع المواد الاساسي وغير الاساسية
                            semester.student_semester_status = SemesterStudentStatusChoice.REGISTERED_FOR_REPEAT
                        elif semester_subjects_is_core > 0  or semester_results['failed_count'] > 0: # اذا يوجد ماده او اكثر من ماده راسب فيها الطالب
                            semester.student_semester_status = SemesterStudentStatusChoice.SUSPENDED_WITH_COURSES
                        else:
                            semester.student_semester_status = SemesterStudentStatusChoice.CLOSED


                        # semester.save()

                        total_failed_subjects += semester_results['failed_count'] or 0

                    # ---------------------------
                    # جلب المواد الراسبة من المستويات السابقة
                    # ---------------------------
                    previous_failed_subjects = self.get_previous_failed_subjects(
                        student_level.fk_student_batch,self.target_level.level
                    )
                    total_failed_subjects += previous_failed_subjects



                    # --------------------------
                    # حساب المجموع الكلي والمتوسط للمستوى
                    # --------------------------
                    # جميع المواد الخاصة بالطالب في هذا المستوى
                    all_subjects = StudentSubject.objects.filter(fk_student_semester__fk_student_level=student_level)
                    # حساب المجموع وعدد المواد
                    level_total = all_subjects.aggregate(total=Sum("total_grade"))['total'] or 0
                    subjects_count = all_subjects.count()

                    # المتوسط = المجموع ÷  عدد المواد
                    level_avg = (level_total / subjects_count) if subjects_count > 0 else 0

                    student_level.total_grade = level_total
                    student_level.avg = level_avg
                    student_level.estimate = self.calculate_estimate(level_avg)


                    # --------------------------
                    # تحديد حالة الطالب في المستوى
                    # --------------------------
                    if total_failed_subjects > self.target_level.allowed_failure_subjects:
                        student_level.estimate = EstimateChoice.POOR
                    else:
                        student_level.is_active = False
                        # تفعيل المستوى التالي (المفروض تم إنشاؤه مسبقا)
                        next_student_level = StudentLevel.objects.filter(
                            fk_student_batch=student_level.fk_student_batch,
                            fk_level__level=self.target_level.level + 1,
                        )
                    
                        if next_student_level:
                            next_student_level.is_active = True
                            # next_student_level.save(update_fields=['is_active'])

                    # student_level.save()

                    # -----------------------
                    # حفظ النتائج النهائية لكل طالب
                    # -----------------------
                    results.append({
                        "student":student_level.fk_student_batch,
                        "total_failed_subjects": total_failed_subjects,
                        "allowd_failure": self.target_level.allowed_failure_subjects,
                        "status": EstimateChoice(student_level.estimate).label,
                        "level_avg": student_level.avg
                    })

            return {
                "success": True,
                "message": f'تم معالجة {len(results)} طالب',
                "results": results
            }

        # except Level.DoesNotExist:
        #     return {
        #         "success": False,
        #         "message": "المستوى المطلوب غير موجود"
        #     }
        # except Exception as e:
        #     return {
        #         "success": False,
        #         "message": f"حدث خطأ: {str(e)}"
        #     }





"""
    سيناريو شاشة ربط الطلاب بالمواد
    ### حقول الفلترة
    1 - الدور للمادة (دور اكتوبر , دور يونيو , دور المعفيين , دور التنازل)
    2 - اختيار السنة
    3 - اختيار الكلية
    4 - اختيار التخصص
    5 - اختيار المستوى # ارجاع المستوى الحالي في دور المعفيين و يونيو
    6 - اختيار الفصل
    7 - اختيار المجموعة
    8 - اختيار اكثر من مادة
    ### البيانات المرجعة
    اسم الطالب  -- رقم الطالب الاكاديمي -- المواد 

    ### 
    1- عمود المواد يتم ارجاع المواد اللي مش مربوطات للطالب اذا كان في دور يونيو
    2- يتم ارجاع المواد اللي راسب فيها الطالب و ربطها بدور اكتوبر 
    3- عند اختيار المواد الذي يريد الطالب التنازل فيها يتم ارجاعها للطالب 
    4- عند اختيار دور معفي يتم ارجاع المواد المعفيه للطالب 

"""